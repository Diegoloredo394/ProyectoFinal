<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="text-xl font-semibold text-gray-900">Nuevo Plan Semanal</h2>
   <?php $__env->endSlot(); ?>

  <div class="p-4 bg-white rounded shadow">
    <form action="<?php echo e(route('plans.store')); ?>" method="POST" class="space-y-4">
      <?php echo csrf_field(); ?>

            <!-- 1. Selector de usuario -->
      <div>
        <label class="block text-gray-700">Asignar a:</label>
        <select name="user_id" class="mt-1 block w-full border-gray-300 rounded">
          <?php $__currentLoopData = \App\Models\User::where('role','member')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>"
              <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
              <?php echo e($user->name); ?> (<?php echo e($user->email); ?>)
            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <!-- Fechas -->
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-gray-700">Fecha inicio</label>
          <input type="date" name="start_date"
                 value="<?php echo e(old('start_date', now()->toDateString())); ?>"
                 class="mt-1 block w-full border-gray-300 rounded">
          <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-red-600"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
          <label class="block text-gray-700">Fecha fin</label>
          <input type="date" name="end_date"
                 value="<?php echo e(old('end_date', now()->addDays(6)->toDateString())); ?>"
                 class="mt-1 block w-full border-gray-300 rounded">
          <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-red-600"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>

      <!-- Selección de recetas por día -->
      <?php
        $days = ['Mon'=>'Lunes','Tue'=>'Martes','Wed'=>'Miércoles',
                 'Thu'=>'Jueves','Fri'=>'Viernes','Sat'=>'Sábado','Sun'=>'Domingo'];
      ?>
      <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="space-y-1">
          <h3 class="font-semibold text-gray-800"><?php echo e($day); ?></h3>
          <div class="grid grid-cols-2 gap-2">
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <label class="inline-flex items-center space-x-2">
                <input type="checkbox"
                       name="recipes[<?php echo e($code); ?>][]"
                       value="<?php echo e($recipe->id); ?>"
                       class="form-checkbox h-4 w-4 text-blue-600">
                <span class="text-gray-700"><?php echo e($recipe->name); ?></span>
              </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div class="text-right">
        <button type="submit"
                class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-500">
          Guardar Plan
        </button>
      </div>
    </form>
  </div>

  <div class="mt-4 p-4">
    <a href="<?php echo e(route('plans.index')); ?>"
       class="text-gray-700 hover:underline">
      Volver al listado de planes
    </a>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\ProyectoFinal\final\resources\views/plans/create.blade.php ENDPATH**/ ?>