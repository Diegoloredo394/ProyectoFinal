<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="text-xl font-semibold text-gray-900">Crear Receta</h2>
   <?php $__env->endSlot(); ?>

  <div class="p-4 bg-white rounded shadow">
    <form action="<?php echo e(route('recipes.store')); ?>" method="POST" class="space-y-4">
      <?php echo csrf_field(); ?>

      <div>
        <label class="block font-medium text-gray-700">Nombre</label>
        <input type="text" name="name" value="<?php echo e(old('name')); ?>"
               class="mt-1 block w-full border-gray-300 rounded" required>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-red-600"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <label class="block font-medium text-gray-700">Descripción</label>
        <textarea name="description" rows="3"
                  class="mt-1 block w-full border-gray-300 rounded"><?php echo e(old('description')); ?></textarea>
      </div>

      <div>
        <label class="block font-medium text-gray-700">Pasos</label>
        <textarea name="steps" rows="5"
                  class="mt-1 block w-full border-gray-300 rounded"><?php echo e(old('steps')); ?></textarea>
      </div>

      <h4 class="font-semibold text-gray-800">Ingredientes</h4>
      <div id="ingredients">
        
        <div class="ingredient-group flex items-center space-x-2">
          <input type="text" name="ingredients[0][name]" placeholder="Ingrediente"
                 class="border-gray-300 rounded px-2 py-1" required>
          <input type="number" name="ingredients[0][quantity]" placeholder="Cant."
                 class="border-gray-300 rounded px-2 py-1" required>
          <input type="text" name="ingredients[0][unit]" placeholder="Unidad"
                 class="border-gray-300 rounded px-2 py-1" required>
          <button type="button" onclick="removeIngredient(this)"
                  class="px-2 py-1 bg-red-600 text-white rounded hover:bg-red-500">
            Eliminar
          </button>
        </div>
      </div>

      <button type="button" onclick="addIngredient()"
              class="mt-2 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-500">
        Agregar ingrediente
      </button>

      <div class="text-right">
        <button type="submit"
                class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-500">
          Guardar Receta
        </button>
      </div>
    </form>
  </div>

  <div class="p-4">
    <a href="<?php echo e(route('recipes.index')); ?>"
       class="text-gray-700 hover:underline">
      ← Volver al listado
    </a>
  </div>

  <script>
    let ingredientIndex = 1;
    function addIngredient() {
      const container = document.getElementById('ingredients');
      const div = document.createElement('div');
      div.className = 'ingredient-group flex items-center space-x-2 mt-2';
      div.innerHTML = `
        <input type="text" name="ingredients[${ingredientIndex}][name]" placeholder="Ingrediente"
               class="border-gray-300 rounded px-2 py-1" required>
        <input type="number" name="ingredients[${ingredientIndex}][quantity]" placeholder="Cant."
               class="border-gray-300 rounded px-2 py-1" required>
        <input type="text" name="ingredients[${ingredientIndex}][unit]" placeholder="Unidad"
               class="border-gray-300 rounded px-2 py-1" required>
        <button type="button" onclick="removeIngredient(this)"
                class="px-2 py-1 bg-red-600 text-white rounded hover:bg-red-500">
          Eliminar
        </button>
      `;
      container.appendChild(div);
      ingredientIndex++;
    }
    function removeIngredient(btn) {
      btn.closest('.ingredient-group')?.remove();
    }
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ProyectoFinal\final\resources\views/recipes/create.blade.php ENDPATH**/ ?>