<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="text-xl font-semibold text-gray-900">
      <?php if(auth()->user()->role === 'admin'): ?>
        Todos los Planes Semanales
      <?php else: ?>
        Mis Planes Semanales
      <?php endif; ?>
    </h2>
   <?php $__env->endSlot(); ?>

  <div class="p-4 space-y-4">
    <?php if(session('success')): ?>
      <div class="p-2 bg-green-100 border border-green-300 text-green-800 rounded">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="grid grid-cols-2 gap-4">
      <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white p-4 rounded shadow hover:shadow-lg transition">
          <h3 class="font-bold text-gray-800"><?php echo e($plan->name); ?></h3>
          <p class="text-sm text-gray-600">
            <?php echo e($plan->start_date); ?> – <?php echo e($plan->end_date); ?>

          </p>
          <div class="mt-2 space-x-2">
            <a href="<?php echo e(route('plans.show', $plan)); ?>"
               class="text-blue-600 hover:underline">
              Ver
            </a>
            <a href="<?php echo e(route('plans.pdf', $plan)); ?>"
               class="text-blue-600 hover:underline">
              PDF
            </a>

            <?php if(auth()->user()->role === 'admin'): ?>
              <a href="<?php echo e(route('plans.edit', $plan)); ?>"
                 class="text-green-600 hover:underline">
                Editar
              </a>

              <form method="POST"
                    action="<?php echo e(route('plans.destroy', $plan)); ?>"
                    class="inline"
                    onsubmit="return confirm('¿Eliminar este plan?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit"
                        class="text-red-600 hover:underline">
                  Eliminar
                </button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if(auth()->user()->role==='admin'): ?>
      <div class="mt-6 text-right">
        <a href="<?php echo e(route('plans.create')); ?>"
           class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-500">
          Nuevo Plan
        </a>
      </div>
    <?php endif; ?>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ProyectoFinal\final\resources\views/plans/index.blade.php ENDPATH**/ ?>