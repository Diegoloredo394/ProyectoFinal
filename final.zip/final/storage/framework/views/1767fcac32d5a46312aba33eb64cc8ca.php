<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Plan <?php echo e($plan->id); ?> PDF</title>
  <style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
    table { width:100%; border-collapse:collapse; margin-top:16px; }
    th, td { border:1px solid #ddd; padding:6px; }
    th { background:#f3f4f6; }
  </style>
</head>
<body>
  <h2>Plan Semanal: <?php echo e($plan->name); ?></h2>
  <p>Usuario: <?php echo e($plan->user->name); ?> (<?php echo e($plan->user->email); ?>)</p>
  <p>Período: <?php echo e($plan->start_date); ?> – <?php echo e($plan->end_date); ?></p>

  <table>
    <tr>
      <th>Día</th>
      <th>Recetas</th>
    </tr>
    <?php $__currentLoopData = ['Mon'=>'Lunes','Tue'=>'Martes','Wed'=>'Miércoles',
              'Thu'=>'Jueves','Fri'=>'Viernes','Sat'=>'Sábado','Sun'=>'Domingo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $dr = $plan->recipes->filter(fn($r)=> $r->pivot->day_of_week === $code);
      ?>
      <tr>
        <td><?php echo e($day); ?></td>
        <td>
          <?php if($dr->isEmpty()): ?>
            —
          <?php else: ?>
            <ul>
              <?php $__currentLoopData = $dr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($r->name); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <p style="margin-top:20px;">Generado: <?php echo e(now()->format('d/m/Y H:i')); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\ProyectoFinal\final\resources\views/plans/pdf.blade.php ENDPATH**/ ?>