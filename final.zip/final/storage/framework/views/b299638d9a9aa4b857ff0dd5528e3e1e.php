<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="text-xl font-semibold text-gray-900">
      <?php echo e($plan->name); ?> (<?php echo e($plan->start_date); ?> – <?php echo e($plan->end_date); ?>)
    </h2>
   <?php $__env->endSlot(); ?>

  <div class="p-4 space-y-6 bg-white rounded shadow">
    <?php
      $days = ['Mon'=>'Lunes','Tue'=>'Martes','Wed'=>'Miércoles',
               'Thu'=>'Jueves','Fri'=>'Viernes','Sat'=>'Sábado','Sun'=>'Domingo'];
    ?>

    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $dayRecipes = $plan->recipes->filter(fn($r)=> $r->pivot->day_of_week === $code);
      ?>
      <div>
        <h3 class="font-semibold text-gray-800"><?php echo e($day); ?></h3>
        <?php if($dayRecipes->isEmpty()): ?>
          <p class="text-gray-600">Sin recetas asignadas</p>
        <?php else: ?>
          <ul class="list-disc pl-5 text-gray-700">
            <?php $__currentLoopData = $dayRecipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($r->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        <?php endif; ?>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <div class="mt-4 p-4 flex space-x-2">
    <a href="<?php echo e(route('plans.index')); ?>"
       class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">
      Volver a mis planes
    </a>
    <a href="<?php echo e(route('plans.pdf', $plan)); ?>"
       class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-500">
      Descargar PDF
    </a>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\ProyectoFinal\final\resources\views/plans/show.blade.php ENDPATH**/ ?>