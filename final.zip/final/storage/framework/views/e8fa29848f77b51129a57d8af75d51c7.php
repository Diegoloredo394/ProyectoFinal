<?php $__env->startComponent('mail::message'); ?>
# Nuevo plan semanal creado

Hola <?php echo e($plan->user->name); ?>,

Adjunto encontrarás tu plan **<?php echo e($plan->name); ?>** (<?php echo e($plan->start_date); ?> – <?php echo e($plan->end_date); ?>) en formato PDF.

Gracias por usar Meal Planner!

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\ProyectoFinal\final\resources\views/emails/plans/created.blade.php ENDPATH**/ ?>